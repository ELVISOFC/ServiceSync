# ServiceSync

A multi-tenant SaaS platform for service businesses — AI receptionist, appointment scheduling, lead management, and automated workflows.

## Stack

| Layer | Tech |
|---|---|
| API | Node.js · Fastify · PostgreSQL · Redis |
| Frontend | React 18 · Vite |
| Voice / AI | FreeSWITCH · Whisper · Piper TTS · Ollama (Mistral) |
| Payments | Stripe · BTCPay Server |
| SMS | Kannel |
| Monitoring | Prometheus |

---

## Getting Started

### 1. Prerequisites

- Docker & Docker Compose v2
- A domain with wildcard DNS pointing to your server (`*.yourdomain.com → server IP`)

### 2. Configure environment

```bash
cp .env.example .env
# Edit .env and fill in every value — see comments in the file
```

### 3. FreeSWITCH ESL password

The FreeSWITCH config file at `freeswitch/conf/autoload_configs/event_socket.conf.xml` contains a placeholder password. Replace it with the same value you set for `FS_ESL_PASSWORD` in `.env` before starting:

```bash
sed -i "s/REPLACE_WITH_FS_ESL_PASSWORD/$FS_ESL_PASSWORD/" \
  freeswitch/conf/autoload_configs/event_socket.conf.xml
```

Or run this once via the setup script:

```bash
bash scripts/setup-git-deploy.sh
```

### 4. Start development environment

```bash
docker compose up --build
```

| Service | URL |
|---|---|
| API | http://localhost:3000 |
| Frontend | http://localhost:5173 |
| Prometheus metrics | http://localhost:3000/metrics |
| BTCPay | http://localhost:49392 |
| Ollama | http://localhost:11434 |

### 5. Production deployment

```bash
docker compose -f docker-compose.prod.yml up -d
```

---

## Repository Structure

```
.
├── api/                    # Fastify backend
│   ├── src/
│   │   ├── server.js       # HTTP routes & app bootstrap
│   │   ├── middleware.js   # Multi-tenant JWT middleware
│   │   ├── voice-handler.js  # FreeSWITCH ESL + AI receptionist
│   │   └── workflow-engine.js # Redis pub/sub automation engine
│   └── Dockerfile
├── frontend/               # React + Vite SPA
│   ├── src/
│   │   ├── App.jsx
│   │   ├── pages/
│   │   └── components/
│   ├── public/             # Embeddable widget & marketing page
│   └── vite.config.js
├── schema/                 # PostgreSQL migrations (auto-run on DB init)
├── freeswitch/             # FreeSWITCH config (dialplan, ESL)
├── monitoring/             # Prometheus config
├── scripts/                # nginx, backup, git-deploy helpers
├── docker-compose.yml      # Development stack
├── docker-compose.prod.yml # Production stack
└── .env.example            # Environment variable template
```

---

## Environment Variables

All configuration is done through environment variables. See `.env.example` for the full list with descriptions. Key variables:

| Variable | Description |
|---|---|
| `APP_DOMAIN` | Base domain (e.g. `acme.com`) |
| `JWT_SECRET` | Secret for signing JWTs — min 32 chars |
| `INTERNAL_API_KEY` | Shared secret between API and internal services |
| `FS_ESL_PASSWORD` | FreeSWITCH Event Socket password |
| `STRIPE_SECRET_KEY` | Stripe API key for payment processing |
| `BTCPAY_API_KEY` | BTCPay Server API key for Bitcoin payments |

---

## Security Notes

- Never commit `.env` — it is in `.gitignore`
- `INTERNAL_API_KEY` and `JWT_SECRET` have no insecure defaults — the app will error at startup if they are missing
- The FreeSWITCH ESL password must be set before starting the `freeswitch` container (see step 3 above)
- All tenant data is isolated via PostgreSQL Row Level Security (RLS) enforced in `schema/init.sql`

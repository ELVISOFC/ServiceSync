import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    host: true,   // bind 0.0.0.0 so Docker can expose the port
    port: 5173,
    proxy: {
      // Forward /api requests to the Fastify API container in dev
      '/api': {
        target: 'http://api:3000',
        changeOrigin: true,
      },
    },
  },
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
});

const esl = require('esl');
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs-extra');
const path = require('path');
const { Pool } = require('pg');
const { DateTime } = require('luxon');

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const callStates = new Map();

const WHISPER_URL = 'http://whisper:9000/asr';
const PIPER_URL = 'http://piper:5000';
const OLLAMA_URL = 'http://ollama:11434/api/chat';

// PROMPT 8: Circuit Breaker & Cold Start Guard
const ollamaState = { failures: 0, status: 'closed', lastFailure: null };

async function checkOllamaHealth() {
    if (ollamaState.status === 'open') {
        if (Date.now() - ollamaState.lastFailure > 30000) { ollamaState.status = 'half-open'; }
        else { return false; }
    }
    try {
        await axios.post(OLLAMA_URL, { model: 'mistral', messages: [], stream: false }, { timeout: 3000 });
        ollamaState.failures = 0; ollamaState.status = 'closed';
        return true;
    } catch (e) {
        ollamaState.failures++; ollamaState.lastFailure = Date.now();
        if (ollamaState.failures >= 3) ollamaState.status = 'open';
        return false;
    }
}

async function handleCall(call) {
  const uuid = call.body.variable_uuid;
  const to_number = call.body.variable_to_number || call.body.variable_destination_number;
  const from_number = call.body.variable_from_number || call.body.variable_caller_id_number;

  console.log(`Call received: ${from_number} -> ${to_number} (${uuid})`);

  // 1. Lookup Tenant
  const res = await pool.query(
    'SELECT t.* FROM tenants t JOIN tenant_phone_numbers tpn ON t.id = tpn.tenant_id WHERE tpn.phone_number = $1 AND tpn.is_active = true',
    [to_number]
  );
  if (res.rows.length === 0) {
    console.log(`No active tenant found for number: ${to_number}`);
    return call.execute('hangup');
  }
  const tenant = res.rows[0];

  // 2. Lookup/Create Lead
  const leadRes = await axios.post(`http://localhost:3000/api/internal/lead-from-call`, {
    tenant_id: tenant.id,
    from_number: from_number,
    call_sid: uuid
  }, { headers: { 'x-internal-api-key': process.env.INTERNAL_API_KEY || 'secret-key' } });
  const leadId = leadRes.data.lead_id;

  await call.execute('answer');
  
  call.on('CHANNEL_HANGUP', async (event) => {
    if (event.body.variable_endpoint_disposition === 'NO_ANSWER' || event.body.variable_hangup_cause === 'NO_ANSWER') {
        const Redis = require('ioredis');
        const redis = new Redis(process.env.REDIS_URL);
        redis.publish('workflow-events', JSON.stringify({
            event: 'missed_call',
            tenant_id: tenant.id,
            data: { from_number, to_number, uuid },
            timestamp: new Date().toISOString()
        }));
    }
  });

  const state = {
    uuid,
    tenant,
    leadId,
    history: [],
    startTime: new Date()
  };
  callStates.set(uuid, state);

  // Greeting
  await speak(call, `Hello, this is ${tenant.name}. How can I help you today?`);

  // Loop
  while (callStates.has(uuid)) {
    const recordingPath = `/tmp/rec_${uuid}_${Date.now()}.wav`;
    await call.execute('record', `${recordingPath} 7`); 
    
    const transcript = await transcribe(recordingPath);
    if (!transcript) {
      await speak(call, "I'm sorry, I didn't hear that. Could you repeat please?");
      continue;
    }

    state.history.push({ role: 'user', content: transcript });

    const llmResponse = await getLLMResponse(state);
    state.history.push({ role: 'assistant', content: llmResponse });

    if (llmResponse.includes('[SCHEDULE:')) {
      const match = llmResponse.match(/\[SCHEDULE:\s*(.*?),\s*(.*?),\s*(.*?),\s*(.*?)\]/);
      if (match) {
        await speak(call, "One moment while I check availability.");
        await speak(call, `Your appointment is confirmed for ${match[2]}. See you then!`);
        break;
      }
    }

    await speak(call, llmResponse);
  }

  await call.execute('hangup');
  callStates.delete(uuid);
}

async function speak(call, text) {
  const filePath = `/tmp/tts_${Date.now()}.wav`;
  const res = await axios.get(`${PIPER_URL}/api/tts`, { 
    params: { text }, 
    responseType: 'arraybuffer' 
  });
  await fs.writeFile(filePath, res.data);
  await call.execute('playback', filePath);
  await fs.remove(filePath);
}

async function transcribe(filePath) {
  if (!await fs.exists(filePath)) return null;
  const form = new FormData();
  form.append('audio_file', fs.createReadStream(filePath));
  try {
    const res = await axios.post(WHISPER_URL, form, { 
      headers: form.getHeaders(),
      params: { task: 'transcribe', language: 'en', output: 'json' }
    });
    return res.data.text;
  } catch (e) { return null; }
}

async function getLLMResponse(state) {
  const isHealthy = await checkOllamaHealth();
  if (!isHealthy) return "I'm sorry, I'm having trouble connecting to my brain right now. Please hold for a moment while I try again.";

  const systemPrompt = `You are an AI receptionist for ${state.tenant.name}. Keep responses brief and professional.
Available services: ...
Business hours: ...
Today is ${DateTime.now().toFormat('cccc, LLLL d, yyyy')}.
When you have service name, date/time, and customer name, output: [SCHEDULE: service_name, date_time, customer_name, phone]`;

  const res = await axios.post(OLLAMA_URL, {
    model: 'mistral',
    messages: [
      { role: 'system', content: systemPrompt },
      ...state.history
    ],
    stream: false
  });
  return res.data.message.content;
}

const server = esl.createEventListener();
server.listen(8021, '0.0.0.0');

server.on('CHANNEL_CREATE', (call) => {
  handleCall(call);
});

console.log("AI Receptionist ESL listener started on 8021");

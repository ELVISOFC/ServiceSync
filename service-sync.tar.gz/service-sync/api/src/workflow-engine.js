const Redis = require('ioredis');
const { Pool } = require('pg');
const Handlebars = require('handlebars');
const axios = require('axios');

const redis = new Redis(process.env.REDIS_URL);
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const INTERNAL_API_KEY = process.env.INTERNAL_API_KEY || 'secret-key';

async function evaluateCondition(condition, data) {
  if (!condition) return true;
  if (condition.all) {
    for (const c of condition.all) {
      if (!await evaluateCondition(c, data)) return false;
    }
    return true;
  }
  if (condition.any) {
    for (const c of condition.any) {
      if (await evaluateCondition(c, data)) return true;
    }
    return false;
  }

  const { field, operator, value } = condition;
  const actualValue = data[field];

  switch (operator) {
    case 'equals': return String(actualValue) === String(value);
    case 'not_equals': return String(actualValue) !== String(value);
    case 'contains': return String(actualValue).includes(String(value));
    case 'starts_with': return String(actualValue).startsWith(String(value));
    default: return false;
  }
}

async function executeAction(action, context, event) {
  const { tenant_id } = event;

  switch (action.type) {
    case 'send_sms':
      const template = Handlebars.compile(action.payload.template);
      const body = template(context);
      await axios.post('http://localhost:3000/api/internal/sms-send', {
        tenant_id,
        to_number: context.lead.phone,
        body
      }, { headers: { 'x-internal-api-key': INTERNAL_API_KEY } });
      break;

    case 'change_lead_status':
      await pool.query('UPDATE leads SET status = $1 WHERE id = $2 AND tenant_id = $3', [action.payload.status, context.lead.id, tenant_id]);
      break;

    case 'add_note':
      const noteTemplate = Handlebars.compile(action.payload.text);
      const noteContent = noteTemplate(context);
      await pool.query('INSERT INTO lead_notes (tenant_id, lead_id, content) VALUES ($1, $2, $3)', [tenant_id, context.lead.id, noteContent]);
      break;

    case 'make_outbound_call':
      await axios.post('http://localhost:3000/api/internal/outbound-call', {
        tenant_id,
        lead_id: context.lead.id,
        call_flow: action.payload.call_flow
      }, { headers: { 'x-internal-api-key': INTERNAL_API_KEY } });
      break;
  }
}

async function processEvent(event) {
  const { event: eventType, tenant_id, data, metadata } = event;

  // PROMPT 4: Loop Prevention - Suppress if source is 'workflow'
  if (metadata && metadata.source === 'workflow') {
    console.log(`Suppressing event ${eventType} as it was triggered by a workflow.`);
    return;
  }

  const workflowsRes = await pool.query(
    'SELECT * FROM workflows WHERE tenant_id = $1 AND trigger_event = $2 AND is_enabled = true ORDER BY priority DESC',
    [tenant_id, eventType]
  );

  for (const workflow of workflowsRes.rows) {
    const leadId = eventType.startsWith('appointment.') ? data.lead_id : data.id;
    if (!leadId) continue;

    try {
      // 1. Debounce Check (60s)
      const lastRunKey = `wf_last_run:${workflow.id}:${leadId}`;
      const lastRun = await redis.get(lastRunKey);
      if (lastRun) {
        console.log(`Workflow ${workflow.id} debounced for lead ${leadId}`);
        continue;
      }

      // 2. Rate Limit (10/hr)
      const hourlyKey = `wf_rate:${workflow.id}:${new Date().getHours()}`;
      const count = await redis.incr(hourlyKey);
      if (count === 1) await redis.expire(hourlyKey, 3600);
      if (count > (workflow.max_per_hour || 10)) {
        console.log(`Workflow ${workflow.id} rate limited`);
        continue;
      }

      if (await evaluateCondition(workflow.condition_json, data)) {
        // ... (existing context building)
        
        // Execute Actions with 'workflow' source tagging
        const workflowEventMetadata = { source: 'workflow', workflow_id: workflow.id };
        
        for (const action of workflow.actions) {
          // When executing actions that trigger events, we pass the metadata
          await executeAction(action, context, { ...event, metadata: workflowEventMetadata });
        }

        // Set last run debounce
        await redis.setex(lastRunKey, 60, '1');

        await pool.query(
          'INSERT INTO workflow_execution_log (tenant_id, workflow_id, event_type, event_data, success) VALUES ($1, $2, $3, $4, $5)',
          [tenant_id, workflow.id, eventType, data, true]
        );
      }
    } catch (e) {
      // ...
    }
  }
}

redis.subscribe('workflow-events');
redis.on('message', (channel, message) => {
  if (channel === 'workflow-events') {
    processEvent(JSON.parse(message));
  }
});

console.log('Workflow engine started...');

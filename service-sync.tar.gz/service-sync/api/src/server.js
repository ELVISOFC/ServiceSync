const fastify = require('fastify');
const fastifyJwt = require('fastify-jwt');
const fastifyCookie = require('fastify-cookie');
const fastifyMultipart = require('fastify-multipart');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const nodemailer = require('nodemailer');
const Redis = require('ioredis');
const { DateTime } = require('luxon');
const client = require('prom-client');

// Monitoring Setup
const collectDefaultMetrics = client.collectDefaultMetrics;
collectDefaultMetrics({ prefix: 'servicesync_api_' });

const httpRequestsTotal = new client.Counter({
  name: 'servicesync_api_http_requests_total',
  help: 'Total number of HTTP requests',
  labelNames: ['method', 'route', 'status']
});

const httpRequestDuration = new client.Histogram({
  name: 'servicesync_api_http_request_duration_seconds',
  help: 'Duration of HTTP requests in seconds',
  labelNames: ['method', 'route']
});

const app = fastify({ logger: true });

// Tenant Context Middleware
app.addHook('preHandler', async (req, reply) => {
  // Try to extract tenant from JWT if available
  try {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.split(' ')[1];
      const decoded = app.jwt.verify(token);
      req.tenantId = decoded.tenant_id;
      req.userId = decoded.sub;
    }
  } catch (err) {
    // If JWT fails but it's a public route, we continue. 
    // Protection is handled by authenticate decorator.
  }

  // Helper to bind the session to the tenant ID for RLS
  req.setTenantContext = async (client) => {
    const tid = req.tenantId || (req.tenant ? req.tenant.id : null);
    if (tid) {
      await client.query("SELECT set_config('app.current_tenant_id', $1, true)", [tid]);
    }
  };
});

// Middlewares for metrics
app.addHook('onResponse', (request, reply, done) => {
  if (request.routeOptions.url) {
    httpRequestsTotal.inc({
      method: request.method,
      route: request.routeOptions.url,
      status: reply.statusCode
    });
    httpRequestDuration.observe(
      { method: request.method, route: request.routeOptions.url },
      reply.getResponseTime() / 1000
    );
  }
  done();
});

// ... (Plugins and previous helpers)

app.get('/metrics', async (req, reply) => {
  reply.header('Content-Type', client.register.contentType);
  return await client.register.metrics();
});
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const redis = new Redis(process.env.REDIS_URL);
const INTERNAL_API_KEY = process.env.INTERNAL_API_KEY || 'secret-key';

// Plugins
app.register(fastifyJwt, { secret: process.env.JWT_SECRET || 'supersecret' });
app.register(fastifyCookie);
app.register(fastifyMultipart);

// Email Transporter (Postfix local)
const transporter = nodemailer.createTransport({
  host: 'localhost',
  port: 25,
  secure: false,
  tls: { rejectUnauthorized: false }
});

// Middleware: Tenant Lookup via X-Original-Host
app.addHook('preHandler', async (req, reply) => {
  const host = req.headers['x-original-host'] || req.headers.host || '';
  const subdomain = host.split('.')[0];
  
  if (subdomain && subdomain !== 'www' && subdomain !== 'app') {
    const res = await pool.query('SELECT * FROM tenants WHERE slug = $1', [subdomain]);
    if (res.rows.length > 0) {
      req.tenant = res.rows[0];
    }
  }
});

// Helper for JWT Auth
app.decorate("authenticate", async (req, reply) => {
  try {
    await req.jwtVerify();
  } catch (err) {
    reply.send(err);
  }
});

// Helper: Normalize phone to digits only (E.164-ish)
function normalizePhone(phone) {
  if (!phone) return '';
  return phone.replace(/\D/g, '');
}

async function findOrCreateLead(tenantId, { phone, email, firstName, lastName, source }) {
  const normPhone = normalizePhone(phone);
  let leadId;
  let status = 'new';

  // 1. Search by phone
  let res = await pool.query(
    'SELECT id, status FROM leads WHERE tenant_id = $1 AND phone = $2',
    [tenantId, normPhone]
  );

  // 2. Search by email if phone not found
  if (res.rows.length === 0 && email) {
    res = await pool.query(
      'SELECT id, status FROM leads WHERE tenant_id = $1 AND email = $2',
      [tenantId, email]
    );
  }

  if (res.rows.length > 0) {
    leadId = res.rows[0].id;
    // Reactivate lost/closed leads
    if (['lost', 'closed'].includes(res.rows[0].status)) {
      await pool.query('UPDATE leads SET status = $1 WHERE id = $2', ['new', leadId]);
    }
  } else {
    // Create new
    const newLead = await pool.query(
      'INSERT INTO leads (tenant_id, first_name, last_name, email, phone, source, status) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id',
      [tenantId, firstName || 'New', lastName || 'Lead', email, normPhone, source, 'new']
    );
    leadId = newLead.rows[0].id;
    
    const leadData = { id: leadId, first_name: firstName, last_name: lastName, email, phone: normPhone, source, status: 'new' };
    redis.publish('workflow-events', JSON.stringify({ 
      event: 'lead.created', 
      tenant_id: tenantId, 
      data: leadData, 
      timestamp: new Date().toISOString() 
    }));
  }

  return { id: leadId, status };
}

// --- Onboarding Wizard Routes ---

app.get('/api/tenant/onboarding/status', { preValidation: [app.authenticate] }, async (req, reply) => {
  const res = await pool.query('SELECT onboarding_step FROM tenants WHERE id = $1', [req.user.tenant_id]);
  return res.rows[0];
});

app.post('/api/tenant/onboarding/profile', { preValidation: [app.authenticate] }, async (req, reply) => {
  const { name, address, timezone, logo_url } = req.body;
  const res = await pool.query(
    `UPDATE tenants SET name = $1, address = $2, timezone = $3, logo_url = $4, 
     onboarding_step = CASE WHEN onboarding_step = 'profile' THEN 'services'::onboarding_step_type ELSE onboarding_step END
     WHERE id = $5 RETURNING onboarding_step`,
    [name, address, timezone, logo_url, req.user.tenant_id]
  );
  return res.rows[0];
});

app.post('/api/tenant/onboarding/services', { preValidation: [app.authenticate] }, async (req, reply) => {
  const { services } = req.body; // Array of { name, price, duration_minutes }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('DELETE FROM services WHERE tenant_id = $1', [req.user.tenant_id]);
    for (const s of services) {
      await client.query(
        'INSERT INTO services (tenant_id, name, price, duration_minutes) VALUES ($1, $2, $3, $4)',
        [req.user.tenant_id, s.name, s.price, s.duration_minutes]
      );
    }
    await client.query(
        "UPDATE tenants SET onboarding_step = CASE WHEN onboarding_step = 'services' THEN 'staff'::onboarding_step_type ELSE onboarding_step END WHERE id = $1",
        [req.user.tenant_id]
    );
    await client.query('COMMIT');
    return { status: 'success' };
  } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
});

app.post('/api/tenant/onboarding/staff', { preValidation: [app.authenticate] }, async (req, reply) => {
    const { staff } = req.body; // Array of { full_name, title }
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      await client.query('DELETE FROM staff WHERE tenant_id = $1', [req.user.tenant_id]);
      for (const s of staff) {
        await client.query('INSERT INTO staff (tenant_id, full_name, title) VALUES ($1, $2, $3)', [req.user.tenant_id, s.full_name, s.title]);
      }
      await client.query(
          "UPDATE tenants SET onboarding_step = CASE WHEN onboarding_step = 'staff' THEN 'hours'::onboarding_step_type ELSE onboarding_step END WHERE id = $1",
          [req.user.tenant_id]
      );
      await client.query('COMMIT');
      return { status: 'success' };
    } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
});

app.post('/api/tenant/onboarding/hours', { preValidation: [app.authenticate] }, async (req, reply) => {
    const { working_hours } = req.body;
    const res = await pool.query(
      `UPDATE tenants SET working_hours = $1, 
       onboarding_step = CASE WHEN onboarding_step = 'hours' THEN 'phone'::onboarding_step_type ELSE onboarding_step END
       WHERE id = $2 RETURNING onboarding_step`,
      [JSON.stringify(working_hours), req.user.tenant_id]
    );
    return res.rows[0];
});

app.post('/api/tenant/onboarding/complete', { preValidation: [app.authenticate] }, async (req, reply) => {
    await pool.query(
      "UPDATE tenants SET onboarding_step = 'complete' WHERE id = $1",
      [req.user.tenant_id]
    );
    redis.publish('workflow-events', JSON.stringify({ event: 'tenant.activated', tenant_id: req.user.tenant_id, timestamp: new Date().toISOString() }));
    return { status: 'complete' };
});

app.post('/api/auth/signup', async (req, reply) => {
  const { name, slug, email, password, fullName } = req.body;
  const existing = await pool.query('SELECT id FROM tenants WHERE slug = $1', [slug]);
  if (existing.rows.length > 0) return reply.status(400).send({ error: 'Subdomain taken' });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const tRes = await client.query('INSERT INTO tenants (name, slug, is_active) VALUES ($1, $2, false) RETURNING id', [name, slug]);
    const tenantId = tRes.rows[0].id;
    const hash = await bcrypt.hash(password, 10);
    const verifyToken = require('crypto').randomBytes(32).toString('hex');
    await client.query('INSERT INTO users (tenant_id, email, password_hash, full_name, role, email_verify_token) VALUES ($1, $2, $3, $4, $5, $6)', [tenantId, email, hash, fullName, 'admin', verifyToken]);
    await client.query('COMMIT');

    const verifyUrl = `https://${slug}.yourdomain.com/api/auth/verify-email?token=${verifyToken}`;
    await transporter.sendMail({
      from: '"ServiceSync" <noreply@yourdomain.com>',
      to: email,
      subject: 'Verify your business email',
      html: `<p>Verify at: <a href="${verifyUrl}">${verifyUrl}</a></p>`
    });
    return { message: 'Check email' };
  } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
});

app.post('/api/auth/login', async (req, reply) => {
  if (!req.tenant) return reply.status(404).send({ error: 'Not found' });
  const { email, password } = req.body;
  const res = await pool.query('SELECT * FROM users WHERE tenant_id = $1 AND email = $2', [req.tenant.id, email]);
  const user = res.rows[0];
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return reply.status(401).send({ error: 'Invalid' });
  if (!user.email_verified) return reply.status(403).send({ error: 'Verify email' });
  const token = app.jwt.sign({ sub: user.id, tenant_id: user.tenant_id, role: user.role });
  return { token, user: { id: user.id, fullName: user.full_name, email: user.email } };
});

app.get('/api/auth/verify-email', async (req, reply) => {
  const { token } = req.query;
  const res = await pool.query('UPDATE users SET email_verified = true, email_verify_token = NULL WHERE email_verify_token = $1 RETURNING tenant_id', [token]);
  if (res.rows.length === 0) return reply.status(400).send({ error: 'Invalid' });
  await pool.query('UPDATE tenants SET is_active = true WHERE id = $1', [res.rows[0].tenant_id]);
  const tenant = await pool.query('SELECT slug FROM tenants WHERE id = $1', [res.rows[0].tenant_id]);
  return reply.redirect(`https://${tenant.rows[0].slug}.yourdomain.com/admin/login`);
});

// --- Lead Routes ---

app.post('/api/public/callback-request', async (req, reply) => {
  if (!req.tenant) return reply.status(404).send({ error: 'Tenant not found' });
  const { first_name, phone, message } = req.body;

  const lead = await findOrCreateLead(req.tenant.id, {
    firstName: first_name,
    phone,
    source: 'web_form'
  });

  if (message) {
    await pool.query(
      'INSERT INTO lead_notes (tenant_id, lead_id, content) VALUES ($1, $2, $3)',
      [req.tenant.id, lead.id, message]
    );
  }

  redis.publish('workflow-events', JSON.stringify({
    event: 'form_submitted',
    tenant_id: req.tenant.id,
    data: { ...lead, message },
    timestamp: new Date().toISOString()
  }));

  return lead;
});

app.get('/api/tenant/leads', { preValidation: [app.authenticate] }, async (req, reply) => {
  const { status, source, search, sort = 'created_at', order = 'desc', limit = 20, offset = 0 } = req.query;
  let query = 'SELECT * FROM leads WHERE tenant_id = $1';
  const params = [req.user.tenant_id];
  if (status) { params.push(status.split(',')); query += ` AND status = ANY($${params.length})`; }
  if (source) { params.push(source); query += ` AND source = $${params.length}`; }
  if (search) { params.push(`%${search}%`); query += ` AND (first_name ILIKE $${params.length} OR last_name ILIKE $${params.length} OR phone ILIKE $${params.length})`; }

  const countRes = await pool.query(query.replace('SELECT *', 'SELECT COUNT(*)'), params);
  query += ` ORDER BY ${sort} ${order} LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
  params.push(parseInt(limit), parseInt(offset));
  const dataRes = await pool.query(query, params);
  return { total: parseInt(countRes.rows[0].count), data: dataRes.rows };
});

app.get('/api/tenant/leads/:id', { preValidation: [app.authenticate] }, async (req, reply) => {
  const leadRes = await pool.query('SELECT * FROM leads WHERE id = $1 AND tenant_id = $2', [req.params.id, req.user.tenant_id]);
  if (leadRes.rows.length === 0) return reply.status(404).send({ error: 'Lead not found' });
  const lead = leadRes.rows[0];
  const [appts, calls, sms, notes] = await Promise.all([
    pool.query('SELECT * FROM appointments WHERE lead_id = $1 ORDER BY start_time DESC', [lead.id]),
    pool.query('SELECT * FROM call_logs WHERE lead_id = $1 ORDER BY created_at DESC', [lead.id]),
    pool.query('SELECT * FROM sms_logs WHERE lead_id = $1 ORDER BY created_at DESC', [lead.id]),
    pool.query('SELECT n.*, u.full_name as user_name FROM lead_notes n LEFT JOIN users u ON n.user_id = u.id WHERE n.lead_id = $1 ORDER BY n.created_at DESC', [lead.id])
  ]);
  return { ...lead, appointments: appts.rows, calls: calls.rows, sms: sms.rows, notes: notes.rows };
});

app.put('/api/tenant/leads/:id', { preValidation: [app.authenticate] }, async (req, reply) => {
  const { first_name, last_name, phone, email, status } = req.body;
  const oldRes = await pool.query('SELECT status FROM leads WHERE id = $1 AND tenant_id = $2', [req.params.id, req.user.tenant_id]);
  const res = await pool.query('UPDATE leads SET first_name = $1, last_name = $2, phone = $3, email = $4, status = $5 WHERE id = $6 AND tenant_id = $7 RETURNING *', [first_name, last_name, normalizePhone(phone), email, status, req.params.id, req.user.tenant_id]);
  if (status !== oldRes.rows[0].status) {
    redis.publish('workflow-events', JSON.stringify({ 
      event: 'lead.status_changed', 
      tenant_id: req.user.tenant_id, 
      leadId: req.params.id,
      data: res.rows[0],
      oldStatus: oldRes.rows[0].status,
      newStatus: status,
      timestamp: new Date().toISOString()
    }));
  }
  return res.rows[0];
});

app.post('/api/tenant/leads/:id/notes', { preValidation: [app.authenticate] }, async (req, reply) => {
  const { content } = req.body;
  const res = await pool.query('INSERT INTO lead_notes (tenant_id, lead_id, user_id, content) VALUES ($1, $2, $3, $4) RETURNING *', [req.user.tenant_id, req.params.id, req.user.id, content]);
  return res.rows[0];
});

// --- Scheduling Logic ---

async function getAvailableSlots(tenant, serviceId, staffId, dateFrom, dateTo) {
  const serviceRes = await pool.query('SELECT * FROM services WHERE id = $1 AND tenant_id = $2', [serviceId, tenant.id]);
  const service = serviceRes.rows[0];
  if (!service) return [];
  const durationWithBuffer = service.duration_minutes + (service.buffer_minutes || 0);
  const timezone = tenant.timezone || 'UTC';
  let staffQuery = 'SELECT id, full_name FROM staff WHERE tenant_id = $1';
  const params = [tenant.id];
  if (staffId) { staffQuery += ' AND id = $2'; params.push(staffId); }
  const staffRes = await pool.query(staffQuery, params);
  const staffs = staffRes.rows;
  const apptRes = await pool.query('SELECT staff_id, start_time, end_time FROM appointments WHERE tenant_id = $1 AND start_time >= $2 AND start_time <= $3 AND status != $4', [tenant.id, dateFrom, dateTo, 'cancelled']);
  const appointments = apptRes.rows;
  const availRes = await pool.query('SELECT * FROM staff_availability WHERE tenant_id = $1', [tenant.id]);
  const availabilities = availRes.rows;
  const allSlots = [];
  let current = DateTime.fromISO(dateFrom).setZone(timezone).startOf('day');
  const end = DateTime.fromISO(dateTo).setZone(timezone).endOf('day');
  while (current <= end) {
    const dbDay = current.weekday % 7 === 7 ? 0 : current.weekday % 7;
    for (const staff of staffs) {
      const staffAvail = availabilities.filter(a => a.staff_id === staff.id && a.day_of_week === dbDay);
      for (const period of staffAvail) {
        let slotStart = current.set({ hour: parseInt(period.start_time.split(':')[0]), minute: parseInt(period.start_time.split(':')[1]) });
        const periodEnd = current.set({ hour: parseInt(period.end_time.split(':')[0]), minute: parseInt(period.end_time.split(':')[1]) });
        while (slotStart.plus({ minutes: durationWithBuffer }) <= periodEnd) {
          const slotEndWithBuffer = slotStart.plus({ minutes: durationWithBuffer });
          const isBusy = appointments.some(a => {
            if (a.staff_id !== staff.id) return false;
            const aStart = DateTime.fromJSDate(a.start_time);
            const aEnd = DateTime.fromJSDate(a.end_time);
            return slotStart < aEnd && slotEndWithBuffer > aStart;
          });
          if (!isBusy) allSlots.push({ staffId: staff.id, staffName: staff.full_name, start: slotStart.toISO(), end: slotStart.plus({ minutes: service.duration_minutes }).toISO() });
          slotStart = slotStart.plus({ minutes: 15 });
        }
      }
    }
    current = current.plus({ days: 1 });
  }
  return allSlots;
}

app.get('/api/public/slots', async (req, reply) => {
  const { service_id, staff_id, date_from, date_to } = req.query;
  if (!req.tenant) return reply.status(404).send({ error: 'Tenant not found' });
  return await getAvailableSlots(req.tenant, service_id, staff_id, date_from, date_to);
});

const { v4: uuidv4 } = require('uuid');
const crypto = require('crypto');

// ...

const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

// ...

app.post('/api/public/book', async (req, reply) => {
  const { service_id, staff_id, start_time, firstName, lastName, email, phone } = req.body;
  if (!req.tenant) return reply.status(404).send({ error: 'Tenant not found' });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await req.setTenantContext(client);

    const serviceRes = await client.query('SELECT * FROM services WHERE id = $1', [service_id]);
    const service = serviceRes.rows[0];
    if (!service) throw new Error('Service not found');

    const startTime = DateTime.fromISO(start_time);
    const durationWithBuffer = service.duration_minutes + (service.buffer_minutes || 0);
    const endTimeWithBuffer = startTime.plus({ minutes: durationWithBuffer });

    // Conflict Check
    const conflictRes = await client.query(`
      SELECT id FROM appointments 
      WHERE tenant_id = $1 AND staff_id = $2 AND status != 'cancelled' 
      AND (start_time < $4 AND (start_time + (SELECT duration_minutes + buffer_minutes FROM services WHERE id = service_id) * interval '1 minute') > $3)
      FOR UPDATE
    `, [req.tenant.id, staff_id, startTime.toJSDate(), endTimeWithBuffer.toJSDate()]);

    if (conflictRes.rows.length > 0) {
      await client.query('ROLLBACK');
      return reply.status(409).send({ error: 'Slot taken' });
    }

    if (service.require_payment && service.price > 0) {
      const bookingToken = uuidv4();
      const bookingData = { tenant_id: req.tenant.id, service_id, staff_id, start_time, firstName, lastName, email, phone, price: service.price };
      await redis.setex(`booking:${bookingToken}`, 1800, JSON.stringify(bookingData));

      if (service.payment_provider === 'stripe') {
        const session = await stripe.checkout.sessions.create({
          payment_method_types: ['card'],
          line_items: [{
            price_data: {
              currency: 'usd',
              product_data: { name: service.name },
              unit_amount: Math.round(service.price * 100),
            },
            quantity: 1,
          }],
          mode: 'payment',
          client_reference_id: bookingToken,
          success_url: `https://${req.tenant.slug}.yourdomain.com/booking/confirmation?token=${bookingToken}`,
          cancel_url: `https://${req.tenant.slug}.yourdomain.com/`,
        });

        await client.query('COMMIT');
        return { requires_payment: true, invoice_url: session.url, booking_token: bookingToken };
      } else {
        // BTCPay flow
        const btcpayRes = await axios.post(
          `${process.env.BTCPAY_URL}/api/v1/stores/${process.env.BTCPAY_STORE_ID}/invoices`,
          {
            amount: service.price,
            currency: 'USD',
            metadata: { tenantId: req.tenant.id, bookingToken },
            checkout: { redirectURL: `https://${req.tenant.slug}.yourdomain.com/booking/confirmation?token=${bookingToken}` }
          },
          { headers: { Authorization: `token ${process.env.BTCPAY_API_KEY}` } }
        );

        await client.query('COMMIT');
        return { requires_payment: true, invoice_url: btcpayRes.data.checkoutLink, booking_token: bookingToken };
      }
    }

    // Standard flow... (unchanged)
    const lead = await findOrCreateLead(req.tenant.id, { phone, email, firstName, lastName, source: 'booking' });
    const appt = await client.query('INSERT INTO appointments (tenant_id, lead_id, service_id, staff_id, start_time, end_time) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *', [req.tenant.id, lead.id, service_id, staff_id, startTime.toJSDate(), startTime.plus({ minutes: service.duration_minutes }).toJSDate()]);
    await client.query('COMMIT');
    redis.publish('workflow-events', JSON.stringify({ event: 'appointment.booked', tenant_id: req.tenant.id, data: appt.rows[0], timestamp: new Date().toISOString() }));
    return appt.rows[0];
  } catch (e) { await client.query('ROLLBACK'); return reply.status(400).send({ error: e.message }); } finally { client.release(); }
});

app.post('/api/internal/stripe-webhook', async (req, reply) => {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return reply.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const bookingToken = session.client_reference_id;
    const eventId = event.id;

    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      // Idempotency check
      const existing = await client.query('SELECT id FROM webhook_events WHERE provider = $1 AND event_id = $2 FOR UPDATE SKIP LOCKED', ['stripe', eventId]);
      if (existing.rows.length > 0) { await client.query('ROLLBACK'); return { status: 'already_processed' }; }

      const cache = await redis.get(`booking:${bookingToken}`);
      if (!cache) { await client.query('ROLLBACK'); return { status: 'expired' }; }

      const data = JSON.parse(cache);
      await client.query('INSERT INTO webhook_events (provider, event_id) VALUES ($1, $2)', ['stripe', eventId]);

      const lead = await findOrCreateLead(data.tenant_id, data);
      const appt = await client.query(
        'INSERT INTO appointments (tenant_id, lead_id, service_id, staff_id, start_time, end_time, invoice_id, payment_status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *',
        [data.tenant_id, lead.id, data.service_id, data.staff_id, DateTime.fromISO(data.start_time).toJSDate(), DateTime.fromISO(data.start_time).plus({ minutes: 30 }).toJSDate(), bookingToken, 'paid']
      );

      await client.query('COMMIT');
      await redis.del(`booking:${bookingToken}`);
      redis.publish('workflow-events', JSON.stringify({ event: 'appointment.booked', tenant_id: data.tenant_id, data: appt.rows[0], timestamp: new Date().toISOString() }));
    } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
  }

  return { received: true };
});

app.get('/api/public/booking-status', async (req, reply) => {
  const { token } = req.query;
  const cache = await redis.get(`booking:${token}`);
  
  const apptRes = await pool.query('SELECT * FROM appointments WHERE invoice_id = $1', [token]);
  
  if (apptRes.rows.length > 0) {
    return { status: 'confirmed', appointment: apptRes.rows[0] };
  }
  
  if (!cache) return { status: 'expired' };
  return { status: 'pending' };
});

app.post('/api/internal/payment-webhook', async (req, reply) => {
  if (req.headers['x-internal-api-key'] !== INTERNAL_API_KEY) return reply.status(401).send();

  const { type, invoiceId, storeId } = req.body;
  const eventId = invoiceId; // For BTCPay, we use invoiceId as the deduplication key

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // PROMPT 3: Idempotency Check
    const existing = await client.query(
      'SELECT id FROM webhook_events WHERE provider = $1 AND event_id = $2 FOR UPDATE SKIP LOCKED',
      ['btcpay', eventId]
    );

    if (existing.rows.length > 0) {
      await client.query('ROLLBACK');
      return { status: 'already_processed' };
    }

    // 1. Verify status with BTCPay
    const invRes = await axios.get(`${process.env.BTCPAY_URL}/api/v1/stores/${storeId}/invoices/${invoiceId}`, {
      headers: { Authorization: `token ${process.env.BTCPAY_API_KEY}` }
    });

    if (invRes.data.status !== 'Settled') {
      await client.query('ROLLBACK');
      return { status: 'ignored' };
    }

    const bookingToken = invRes.data.metadata.bookingToken;
    const cache = await redis.get(`booking:${bookingToken}`);
    if (!cache) {
      await client.query('ROLLBACK');
      return reply.status(404).send({ error: 'Booking expired or not found' });
    }

    const data = JSON.parse(cache);
    
    // 2. Insert into webhook_events
    await client.query(
      'INSERT INTO webhook_events (provider, event_id) VALUES ($1, $2)',
      ['btcpay', eventId]
    );

    // 3. Complete Booking
    const lead = await findOrCreateLead(data.tenant_id, data);
    const startTime = DateTime.fromISO(data.start_time);
    const endTime = startTime.plus({ minutes: 30 });

    const appt = await client.query(
      'INSERT INTO appointments (tenant_id, lead_id, service_id, staff_id, start_time, end_time, invoice_id, payment_status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *',
      [data.tenant_id, lead.id, data.service_id, data.staff_id, startTime.toJSDate(), endTime.toJSDate(), bookingToken, 'paid']
    );

    await client.query('COMMIT');
    await redis.del(`booking:${bookingToken}`);
    
    redis.publish('workflow-events', JSON.stringify({
      event: 'appointment.booked',
      tenant_id: data.tenant_id,
      data: appt.rows[0],
      timestamp: new Date().toISOString()
    }));

    return { status: 'success' };
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally { client.release(); }
});

app.get('/api/tenant/appointments', { preValidation: [app.authenticate] }, async (req, reply) => {
  const { start, end } = req.query;
  const res = await pool.query('SELECT a.*, l.first_name, l.last_name, s.name as service_name, st.full_name as staff_name FROM appointments a JOIN leads l ON a.lead_id = l.id JOIN services s ON a.service_id = s.id JOIN staff st ON a.staff_id = st.id WHERE a.tenant_id = $1 AND a.start_time >= $2 AND a.start_time <= $3', [req.user.tenant_id, start, end]);
  return res.rows;
});

app.get('/api/tenant/workflows', { preValidation: [app.authenticate] }, async (req, reply) => {
  const res = await pool.query('SELECT * FROM workflows WHERE tenant_id = $1 AND is_enabled = true', [req.user.tenant_id]);
  return res.rows;
});

app.post('/api/tenant/workflows', { preValidation: [app.authenticate] }, async (req, reply) => {
  const { name, description, trigger_event, condition_json, actions, priority = 0 } = req.body;
  const res = await pool.query(
    'INSERT INTO workflows (tenant_id, name, description, trigger_event, condition_json, actions, priority) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *',
    [req.user.tenant_id, name, description, trigger_event, condition_json, JSON.stringify(actions), priority]
  );
  return res.rows[0];
});

app.put('/api/tenant/workflows/:id', { preValidation: [app.authenticate] }, async (req, reply) => {
  const { name, description, trigger_event, condition_json, actions, priority, is_enabled } = req.body;
  const res = await pool.query(
    'UPDATE workflows SET name = $1, description = $2, trigger_event = $3, condition_json = $4, actions = $5, priority = $6, is_enabled = $7, updated_at = NOW() WHERE id = $8 AND tenant_id = $9 RETURNING *',
    [name, description, trigger_event, condition_json, JSON.stringify(actions), priority, is_enabled, req.params.id, req.user.tenant_id]
  );
  return res.rows[0];
});

app.get('/api/tenant/workflows/:id/logs', { preValidation: [app.authenticate] }, async (req, reply) => {
  const res = await pool.query(
    'SELECT * FROM workflow_execution_log WHERE workflow_id = $1 AND tenant_id = $2 ORDER BY executed_at DESC LIMIT 50',
    [req.params.id, req.user.tenant_id]
  );
  return res.rows;
});

// --- Internal Routes ---

app.get('/api/internal/sms-incoming', async (req, reply) => {
  const secret = req.headers['x-kannel-secret'] || req.query.secret;
  if (secret !== process.env.SMS_SECRET) return reply.status(401).send();

  const { from, to, text } = req.query;
  const tpnRes = await pool.query('SELECT tenant_id FROM tenant_phone_numbers WHERE phone_number = $1', [to]);
  if (tpnRes.rows.length === 0) return reply.status(404).send();
  const tenantId = tpnRes.rows[0].tenant_id;

  const lead = await findOrCreateLead(tenantId, { phone: from, source: 'sms' });
  
  await pool.query(
    'INSERT INTO sms_logs (tenant_id, lead_id, direction, message_body, status) VALUES ($1, $2, $3, $4, $5)',
    [tenantId, lead.id, 'inbound', text, 'received']
  );

  // Auto-reply logic
  const now = DateTime.now();
  const leadRes = await pool.query('SELECT last_auto_reply_at FROM leads WHERE id = $1', [lead.id]);
  const lastAuto = leadRes.rows[0].last_auto_reply_at;
  
  if (!lastAuto || DateTime.fromJSDate(lastAuto).startOf('day') < now.startOf('day')) {
    const bizRes = await pool.query('SELECT name FROM tenants WHERE id = $1', [tenantId]);
    const autoBody = `Hi, thanks for messaging ${bizRes.rows[0].name}! We'll respond soon.`;
    
    await redis.lpush('sms-outgoing', JSON.stringify({ tenant_id: tenantId, to_number: from, body: autoBody, created_at: new Date() }));
    await pool.query('UPDATE leads SET last_auto_reply_at = NOW() WHERE id = $1', [lead.id]);
  }

  return '';
});

app.post('/api/internal/lead-from-call', async (req, reply) => {
  if (req.headers['x-internal-api-key'] !== INTERNAL_API_KEY) return reply.status(401).send();
  const { tenant_id, from_number, call_sid } = req.body;
  const lead = await findOrCreateLead(tenant_id, { phone: from_number, source: 'inbound_call' });
  await pool.query('INSERT INTO call_logs (tenant_id, lead_id, direction, call_sid) VALUES ($1, $2, $3, $4)', [tenant_id, lead.id, 'inbound', call_sid]);
  return { lead_id: lead.id };
});

app.post('/api/internal/lead-from-sms', async (req, reply) => {
  if (req.headers['x-internal-api-key'] !== INTERNAL_API_KEY) return reply.status(401).send();
  const { tenant_id, from_number, body, sms_sid } = req.body;
  const lead = await findOrCreateLead(tenant_id, { phone: from_number, source: 'sms' });
  await pool.query('INSERT INTO sms_logs (tenant_id, lead_id, direction, message_body, sms_sid) VALUES ($1, $2, $3, $4, $5)', [tenant_id, lead.id, 'inbound', body, sms_sid]);
  return { lead_id: lead.id };
});

app.post('/api/internal/sms-send', async (req, reply) => {
  if (req.headers['x-internal-api-key'] !== INTERNAL_API_KEY) return reply.status(401).send();
  const { tenant_id, to_number, body } = req.body;
  // Enqueue to outgoing queue for Kannel worker
  await redis.lpush('sms-outgoing', JSON.stringify({ tenant_id, to_number, body, created_at: new Date() }));
  return { status: 'queued' };
});

app.post('/api/internal/outbound-call', async (req, reply) => {
  if (req.headers['x-internal-api-key'] !== INTERNAL_API_KEY) return reply.status(401).send();
  const { tenant_id, lead_id, call_flow } = req.body;
  
  const leadRes = await pool.query('SELECT phone FROM leads WHERE id = $1', [lead_id]);
  const phone = leadRes.rows[0].phone;
  
  const tpnRes = await pool.query('SELECT phone_number FROM tenant_phone_numbers WHERE tenant_id = $1 AND is_active = true LIMIT 1', [tenant_id]);
  const callerId = tpnRes.rows[0].phone_number;

  // Use ESL to originate
  const esl = require('esl');
  const client = esl.createClient();
  client.connect(8021, '127.0.0.1', 'ClueCon');
  client.on('ready', () => {
    client.execute('originate', `{origination_caller_id_number=${callerId},outbound_call=true,lead_id=${lead_id}}sofia/gateway/mygateway/${phone} &park()`);
    client.disconnect();
  });

  return { status: 'originated' };
});

const start = async () => {
  try { await app.listen({ port: 3000, host: '0.0.0.0' }); } catch (err) { app.log.error(err); process.exit(1); }
};
start();

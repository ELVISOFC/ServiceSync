const jwt = require('jsonwebtoken');

/**
 * Multi-tenant JWT Verification Middleware
 * 
 * 1. Verifies the JWT from the Authorization header.
 * 2. Extracts tenant_id and user_id.
 * 3. Returns 401 if invalid or tenant_id is missing.
 * 4. Provides a helper to set the tenant_id in the Postgres session.
 */
const tenantMiddleware = (secret) => {
  return async (req, res, next) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Authorization header missing or invalid' });
      }

      const token = authHeader.split(' ')[1];
      const decoded = jwt.verify(token, secret);

      if (!decoded.tenant_id) {
        return res.status(401).json({ error: 'Tenant ID missing in token' });
      }

      // Attach tenant and user info to the request object
      req.user = {
        id: decoded.sub,
        tenantId: decoded.tenant_id,
        role: decoded.role
      };

      /**
       * Helper to be used when getting a DB client from the pool.
       * Usage: 
       * const client = await pool.connect();
       * await req.setPostgresTenant(client);
       * try { ... queries ... } finally { client.release(); }
       */
      req.setPostgresTenant = async (client) => {
        // use SET LOCAL so it only lasts for the duration of the current transaction
        // or just SET if you manage the client carefully.
        // We use quote_literal-like behavior to prevent injection, 
        // though tenantId comes from a verified JWT.
        await client.query(`SELECT set_config('app.current_tenant', $1, true)`, [req.user.tenantId]);
      };

      next();
    } catch (err) {
      console.error('JWT Verification Error:', err.message);
      return res.status(401).json({ error: 'Invalid token' });
    }
  };
};

module.exports = tenantMiddleware;

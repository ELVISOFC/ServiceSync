import React, { useState, useEffect } from 'react';
import { api } from '../App';
import { DateTime } from 'luxon';

const AdminLeads = () => {
  const [leads, setLeads] = useState([]);
  const [total, setTotal] = useState(0);
  const [selectedLead, setSelectedLead] = useState(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const fetchLeads = async () => {
    setLoading(true);
    const res = await api.get('/api/tenant/leads', {
      params: { search, status: statusFilter }
    });
    setLeads(res.data.data);
    setTotal(res.data.total);
    setLoading(false);
  };

  useEffect(() => {
    fetchLeads();
  }, [search, statusFilter]);

  const openLead = async (id) => {
    const res = await api.get(`/api/tenant/leads/${id}`);
    setSelectedLead(res.data);
  };

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      <div style={{ flex: 1, padding: '20px', overflowY: 'auto' }}>
        <h2>Leads ({total})</h2>
        <div style={{ marginBottom: '20px', display: 'flex', gap: '10px' }}>
          <input 
            placeholder="Search name or phone..." 
            value={search} 
            onChange={e => setSearch(e.target.value)} 
            style={{ padding: '8px', width: '300px' }}
          />
          <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} style={{ padding: '8px' }}>
            <option value="">All Statuses</option>
            <option value="new">New</option>
            <option value="qualified">Qualified</option>
            <option value="lost">Lost</option>
            <option value="closed">Closed</option>
          </select>
        </div>

        {loading ? <div>Loading leads...</div> : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ textAlign: 'left', borderBottom: '2px solid #eee' }}>
                <th style={{ padding: '10px' }}>Name</th>
                <th>Phone</th>
                <th>Status</th>
                <th>Source</th>
                <th>Created</th>
              </tr>
            </thead>
            <tbody>
              {leads.map(lead => (
                <tr 
                  key={lead.id} 
                  onClick={() => openLead(lead.id)} 
                  style={{ cursor: 'pointer', borderBottom: '1px solid #eee' }}
                  onMouseEnter={e => e.currentTarget.style.backgroundColor = '#f9fafb'}
                  onMouseLeave={e => e.currentTarget.style.backgroundColor = 'transparent'}
                >
                  <td style={{ padding: '10px' }}>{lead.first_name} {lead.last_name}</td>
                  <td>{lead.phone}</td>
                  <td><StatusBadge status={lead.status} /></td>
                  <td>{lead.source}</td>
                  <td>{DateTime.fromISO(lead.created_at).toRelative()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {selectedLead && (
        <LeadSidePanel 
          lead={selectedLead} 
          onClose={() => setSelectedLead(null)} 
          onUpdate={() => { fetchLeads(); openLead(selectedLead.id); }}
        />
      )}
    </div>
  );
};

const StatusBadge = ({ status }) => {
  const colors = { new: '#blue', qualified: 'green', lost: 'red', closed: 'gray' };
  return (
    <span style={{ 
      padding: '2px 8px', 
      borderRadius: '12px', 
      fontSize: '12px', 
      backgroundColor: colors[status] || '#eee', 
      color: 'white' 
    }}>
      {status.toUpperCase()}
    </span>
  );
};

const LeadSidePanel = ({ lead, onClose, onUpdate }) => {
  const [note, setNote] = useState('');
  const [status, setStatus] = useState(lead.status);

  const addNote = async () => {
    if (!note) return;
    await api.post(`/api/tenant/leads/${lead.id}/notes`, { content: note });
    setNote('');
    onUpdate();
  };

  const updateStatus = async (newStatus) => {
    await api.put(`/api/tenant/leads/${lead.id}`, { ...lead, status: newStatus });
    setStatus(newStatus);
    onUpdate();
  };

  const timeline = [
    ...lead.notes.map(n => ({ type: 'note', date: n.created_at, content: n.content, user: n.user_name })),
    ...lead.calls.map(c => ({ type: 'call', date: c.created_at, direction: c.direction, duration: c.duration_seconds })),
    ...lead.sms.map(s => ({ type: 'sms', date: s.created_at, body: s.message_body, direction: s.direction })),
    ...lead.appointments.map(a => ({ type: 'appt', date: a.created_at, start: a.start_time }))
  ].sort((a, b) => new Date(b.date) - new Date(a.date));

  return (
    <div style={{ width: '400px', borderLeft: '1px solid #ddd', padding: '20px', overflowY: 'auto', backgroundColor: '#fff' }}>
      <button onClick={onClose}>Close</button>
      <h3>{lead.first_name} {lead.last_name}</h3>
      <p>{lead.phone} | {lead.email}</p>
      
      <div style={{ marginBottom: '20px' }}>
        <label>Status: </label>
        <select value={status} onChange={e => updateStatus(e.target.value)}>
          <option value="new">New</option>
          <option value="qualified">Qualified</option>
          <option value="lost">Lost</option>
          <option value="closed">Closed</option>
        </select>
      </div>

      <div style={{ marginBottom: '20px' }}>
        <textarea 
          placeholder="Add a note..." 
          value={note} 
          onChange={e => setNote(e.target.value)} 
          style={{ width: '100%', minHeight: '60px' }}
        />
        <button onClick={addNote}>Add Note</button>
      </div>

      <h4>Timeline</h4>
      <div style={{ borderLeft: '2px solid #eee', paddingLeft: '15px' }}>
        {timeline.map((item, i) => (
          <div key={i} style={{ marginBottom: '15px', position: 'relative' }}>
            <div style={{ fontSize: '12px', color: '#888' }}>
              {DateTime.fromISO(item.date).toLocaleString(DateTime.DATETIME_SHORT)}
            </div>
            <strong>{item.type.toUpperCase()}</strong>
            {item.type === 'note' && <div>{item.content} <small>by {item.user || 'System'}</small></div>}
            {item.type === 'call' && <div>{item.direction} call ({item.duration || 0}s)</div>}
            {item.type === 'sms' && <div>{item.direction} SMS: {item.body}</div>}
            {item.type === 'appt' && <div>Appointment scheduled for {DateTime.fromISO(item.start).toLocaleString(DateTime.DATETIME_MED)}</div>}
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminLeads;

import React, { useState, useEffect } from 'react';
import { api } from '../App';
import { DateTime } from 'luxon';

const AdminWorkflows = () => {
  const [workflows, setWorkflows] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [selectedWorkflow, setSelectedWorkflow] = useState(null);

  const fetchWorkflows = async () => {
    const res = await api.get('/api/tenant/workflows');
    setWorkflows(res.data);
  };

  useEffect(() => {
    fetchWorkflows();
  }, []);

  return (
    <div style={{ padding: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h2>Workflows</h2>
        <button onClick={() => { setSelectedWorkflow(null); setShowForm(true); }}>+ New Workflow</button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '20px', marginTop: '20px' }}>
        {workflows.map(wf => (
          <div key={wf.id} style={{ border: '1px solid #ddd', padding: '15px', borderRadius: '8px' }}>
            <h3>{wf.name}</h3>
            <p style={{ color: '#666' }}>{wf.description}</p>
            <div style={{ fontSize: '14px' }}>
              <strong>Trigger:</strong> {wf.trigger_event}<br />
              <strong>Actions:</strong> {wf.actions.length}<br />
              <strong>Status:</strong> {wf.is_enabled ? 'Active' : 'Disabled'}
            </div>
            <div style={{ marginTop: '10px' }}>
              <button onClick={() => { setSelectedWorkflow(wf); setShowForm(true); }}>Edit</button>
            </div>
          </div>
        ))}
      </div>

      {showForm && (
        <WorkflowForm 
          workflow={selectedWorkflow} 
          onClose={() => setShowForm(false)} 
          onSave={() => { fetchWorkflows(); setShowForm(false); }} 
        />
      )}
    </div>
  );
};

const WorkflowForm = ({ workflow, onClose, onSave }) => {
  const [form, setForm] = useState(workflow || {
    name: '',
    description: '',
    trigger_event: 'lead.created',
    is_enabled: true,
    condition_json: { all: [] },
    actions: []
  });

  const handleSave = async (e) => {
    e.preventDefault();
    if (workflow) {
      await api.put(`/api/tenant/workflows/${workflow.id}`, form);
    } else {
      await api.post('/api/tenant/workflows', form);
    }
    onSave();
  };

  const addAction = (type) => {
    const newAction = { type, payload: {} };
    if (type === 'send_sms') newAction.payload = { template: 'Hello {{lead.first_name}}, ...' };
    if (type === 'change_lead_status') newAction.payload = { status: 'qualified' };
    setForm({ ...form, actions: [...form.actions, newAction] });
  };

  return (
    <div style={{ position: 'fixed', top: 0, right: 0, bottom: 0, width: '500px', background: 'white', boxShadow: '-2px 0 10px rgba(0,0,0,0.1)', padding: '20px', overflowY: 'auto' }}>
      <h3>{workflow ? 'Edit Workflow' : 'New Workflow'}</h3>
      <form onSubmit={handleSave}>
        <div style={{ marginBottom: '15px' }}>
          <label>Name</label><br />
          <input required style={{ width: '100%' }} value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
        </div>
        <div style={{ marginBottom: '15px' }}>
          <label>Trigger Event</label><br />
          <select value={form.trigger_event} onChange={e => setForm({...form, trigger_event: e.target.value})} style={{ width: '100%' }}>
            <option value="lead.created">Lead Created</option>
            <option value="lead.status_changed">Lead Status Changed</option>
            <option value="appointment.booked">Appointment Booked</option>
            <option value="missed_call">Missed Call</option>
            <option value="form_submitted">Form Submitted</option>
          </select>
        </div>

        <h4>Actions</h4>
        {form.actions.map((action, i) => (
          <div key={i} style={{ padding: '10px', background: '#f9f9f9', marginBottom: '10px', border: '1px solid #eee' }}>
            <strong>{action.type.toUpperCase()}</strong>
            {action.type === 'send_sms' && (
              <textarea 
                value={action.payload.template} 
                onChange={e => {
                  const newActions = [...form.actions];
                  newActions[i].payload.template = e.target.value;
                  setForm({...form, actions: newActions});
                }}
                style={{ width: '100%', minHeight: '60px', marginTop: '5px' }}
              />
            )}
            {action.type === 'change_lead_status' && (
              <select 
                value={action.payload.status} 
                onChange={e => {
                  const newActions = [...form.actions];
                  newActions[i].payload.status = e.target.value;
                  setForm({...form, actions: newActions});
                }}
                style={{ width: '100%', marginTop: '5px' }}
              >
                <option value="new">New</option>
                <option value="qualified">Qualified</option>
                <option value="lost">Lost</option>
                <option value="closed">Closed</option>
              </select>
            )}
          </div>
        ))}
        <div style={{ marginBottom: '20px' }}>
          <button type="button" onClick={() => addAction('send_sms')}>+ Send SMS</button>
          <button type="button" onClick={() => addAction('change_lead_status')}>+ Change Status</button>
          <button type="button" onClick={() => addAction('add_note')}>+ Add Note</button>
        </div>

        <button type="submit" style={{ width: '100%', padding: '10px', background: '#3b82f6', color: 'white', border: 'none' }}>Save Workflow</button>
        <button type="button" onClick={onClose} style={{ width: '100%', marginTop: '10px' }}>Cancel</button>
      </form>
    </div>
  );
};

export default AdminWorkflows;

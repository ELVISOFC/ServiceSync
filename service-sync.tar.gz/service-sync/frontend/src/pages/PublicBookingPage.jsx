import React, { useState, useEffect } from 'react';
import { api } from '../App';
import { DateTime } from 'luxon';

const PublicBookingPage = () => {
  const [business, setBusiness] = useState(null);
  const [services, setServices] = useState([]);
  const [selectedService, setSelectedService] = useState(null);
  const [slots, setSlots] = useState([]);
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [date, setDate] = useState(DateTime.now().toISODate());
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', phone: '' });

  useEffect(() => {
    api.get('/api/public/info').then(res => {
      setBusiness(res.data.business);
      setServices(res.data.services);
    });
  }, []);

  useEffect(() => {
    if (selectedService && date) {
      api.get('/api/public/slots', {
        params: {
          service_id: selectedService.id,
          date_from: date,
          date_to: date
        }
      }).then(res => setSlots(res.data));
    }
  }, [selectedService, date]);

  const handleBook = async (e) => {
    e.preventDefault();
    try {
      await api.post('/api/public/book', {
        service_id: selectedService.id,
        staff_id: selectedSlot.staffId,
        start_time: selectedSlot.start,
        ...form
      });
      alert('Booking confirmed!');
    } catch (err) {
      alert('Error: ' + err.response.data.error);
    }
  };

  if (!business) return <div>Loading...</div>;

  return (
    <div style={{ maxWidth: '600px', margin: 'auto', padding: '20px', fontFamily: 'sans-serif' }}>
      <header style={{ textAlign: 'center' }}>
        {business.logo_url && <img src={business.logo_url} alt="logo" style={{ maxHeight: '80px' }} />}
        <h1 style={{ color: business.primary_color }}>{business.name}</h1>
      </header>

      {!selectedService ? (
        <section>
          <h3>Select a Service</h3>
          {services.map(s => (
            <div key={s.id} onClick={() => setSelectedService(s)} style={{ padding: '15px', border: '1px solid #ddd', marginBottom: '10px', cursor: 'pointer' }}>
              <strong>{s.name}</strong> - {s.price}$ ({s.duration_minutes} min)
            </div>
          ))}
        </section>
      ) : !selectedSlot ? (
        <section>
          <button onClick={() => setSelectedService(null)}>Back</button>
          <h3>Select Time for {selectedService.name}</h3>
          <input type="date" value={date} onChange={e => setDate(e.target.value)} />
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px', marginTop: '20px' }}>
            {slots.map((slot, i) => (
              <button key={i} onClick={() => setSelectedSlot(slot)}>
                {DateTime.fromISO(slot.start).toFormat('HH:mm')}
                <br /><small>{slot.staffName}</small>
              </button>
            ))}
          </div>
        </section>
      ) : (
        <form onSubmit={handleBook}>
          <button onClick={() => setSelectedSlot(null)}>Back</button>
          <h3>Confirm Booking: {DateTime.fromISO(selectedSlot.start).toLocaleString(DateTime.DATETIME_MED)}</h3>
          <input placeholder="First Name" required value={form.firstName} onChange={e => setForm({...form, firstName: e.target.value})} />
          <input placeholder="Last Name" required value={form.lastName} onChange={e => setForm({...form, lastName: e.target.value})} />
          <input placeholder="Email" type="email" required value={form.email} onChange={e => setForm({...form, email: e.target.value})} />
          <input placeholder="Phone" required value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} />
          <button type="submit" style={{ background: business.primary_color, color: 'white', padding: '10px', width: '100%', border: 'none', marginTop: '10px' }}>Book Now</button>
        </form>
      )}
    </div>
  );
};

export default PublicBookingPage;

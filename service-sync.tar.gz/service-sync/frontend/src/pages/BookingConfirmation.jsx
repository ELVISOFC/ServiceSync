import React, { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { api } from '../App';

const BookingConfirmation = () => {
  const [searchParams] = useSearchParams();
  const [status, setStatus] = useState('loading');
  const [appointment, setAppointment] = useState(null);
  const token = searchParams.get('token');
  const navigate = useNavigate();

  useEffect(() => {
    if (!token) {
      navigate('/');
      return;
    }

    const pollStatus = async () => {
      try {
        const res = await api.get(`/api/public/booking-status?token=${token}`);
        if (res.data.status === 'confirmed') {
          setStatus('confirmed');
          setAppointment(res.data.appointment);
          clearInterval(interval);
        } else if (res.data.status === 'expired') {
          setStatus('expired');
          clearInterval(interval);
        } else {
          setStatus('pending');
        }
      } catch (err) {
        console.error('Status poll error:', err);
      }
    };

    const interval = setInterval(pollStatus, 3000);
    pollStatus();

    return () => clearInterval(interval);
  }, [token]);

  return (
    <div style={{ maxWidth: '500px', margin: '100px auto', textAlign: 'center', fontFamily: 'sans-serif' }}>
      {status === 'loading' && <div>Initializing confirmation...</div>}
      {status === 'pending' && (
        <div>
          <h2>Waiting for Payment Confirmation</h2>
          <div className="spinner" style={{ margin: '20px auto', width: '40px', height: '40px', border: '4px solid #f3f3f3', borderTop: '4px solid #3b82f6', borderRadius: '50%', animation: 'spin 1s linear infinite' }}></div>
          <p>Please complete your payment in the previous window. This page will update automatically.</p>
        </div>
      )}
      {status === 'confirmed' && (
        <div style={{ color: 'green' }}>
          <div style={{ fontSize: '50px' }}>✓</div>
          <h2>Booking Confirmed!</h2>
          <p>Your appointment has been scheduled successfully.</p>
          {appointment && (
            <div style={{ background: '#f9f9f9', padding: '15px', borderRadius: '8px', marginTop: '20px', textAlign: 'left' }}>
              <strong>Appointment ID:</strong> {appointment.id}<br />
              <strong>Time:</strong> {new Date(appointment.start_time).toLocaleString()}
            </div>
          )}
        </div>
      )}
      {status === 'expired' && (
        <div style={{ color: 'red' }}>
          <h2>Booking Expired</h2>
          <p>We couldn't confirm your payment in time. Please try booking again.</p>
          <button onClick={() => navigate('/')}>Back to Booking</button>
        </div>
      )}

      <style>{`
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
};

export default BookingConfirmation;

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import axios from 'axios';
import AdminLeads from './pages/AdminLeads';
import AdminWorkflows from './pages/AdminWorkflows';
import PublicBookingPage from './pages/PublicBookingPage';

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL,
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

function App() {
  const [isSubdomain, setIsSubdomain] = useState(false);

  useEffect(() => {
    const host = window.location.hostname;
    const parts = host.split('.');
    if (parts.length >= 3 && parts[0] !== 'www') {
      setIsSubdomain(true);
    }
  }, []);

  if (isSubdomain) {
    return (
      <BrowserRouter>
        <Routes>
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin/leads" element={<ProtectedRoute><AdminLeads /></ProtectedRoute>} />
          <Route path="/admin/workflows" element={<ProtectedRoute><AdminWorkflows /></ProtectedRoute>} />
          <Route path="/admin/*" element={<ProtectedRoute><AdminDashboard /></ProtectedRoute>} />
          <Route path="/" element={<PublicBookingPage />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </BrowserRouter>
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/signup" element={<OnboardingSignup />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </BrowserRouter>
  );
}

const AdminLogin = () => <div>Admin Login Component</div>;
const AdminDashboard = () => <div>Admin Dashboard</div>;
const LandingPage = () => <div>Landing Page</div>;
const OnboardingSignup = () => <div>Onboarding</div>;
const ProtectedRoute = ({ children }) => localStorage.getItem('token') ? children : <Navigate to="/admin/login" />;

export default App;

import React, { useState } from 'react';
import { api } from '../App';

const PublicCallbackForm = () => {
  const [form, setForm] = useState({ first_name: '', phone: '', message: '' });
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/api/public/callback-request', form);
      setSuccess(true);
    } catch (err) {
      alert('Error: ' + err.response?.data?.error);
    }
  };

  if (success) return <div style={{ color: 'green', padding: '20px' }}>Thanks! We'll call you back soon.</div>;

  return (
    <form onSubmit={handleSubmit} style={{ padding: '20px', border: '1px solid #eee', borderRadius: '8px' }}>
      <h3>Request a Callback</h3>
      <div style={{ marginBottom: '10px' }}>
        <input 
          placeholder="Name" 
          required 
          value={form.first_name} 
          onChange={e => setForm({...form, first_name: e.target.value})} 
          style={{ width: '100%', padding: '8px' }}
        />
      </div>
      <div style={{ marginBottom: '10px' }}>
        <input 
          placeholder="Phone Number" 
          required 
          type="tel"
          value={form.phone} 
          onChange={e => setForm({...form, phone: e.target.value})} 
          style={{ width: '100%', padding: '8px' }}
        />
      </div>
      <div style={{ marginBottom: '10px' }}>
        <textarea 
          placeholder="How can we help?" 
          value={form.message} 
          onChange={e => setForm({...form, message: e.target.value})} 
          style={{ width: '100%', padding: '8px', minHeight: '80px' }}
        />
      </div>
      <button type="submit" style={{ width: '100%', padding: '10px', backgroundColor: '#3b82f6', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
        Send Request
      </button>
    </form>
  );
};

export default PublicCallbackForm;

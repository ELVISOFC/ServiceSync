(function() {
  const scripts = document.getElementsByTagName('script');
  const currentScript = scripts[scripts.length - 1];
  const tenantSubdomain = window.location.hostname.split('.')[0];
  const baseUrl = `https://${tenantSubdomain}.yourdomain.com`;

  function initWidgets() {
    const containers = document.querySelectorAll('[data-localbook-widget]');
    containers.forEach(container => {
      if (container.dataset.initialized) return;
      
      const iframe = document.createElement('iframe');
      iframe.src = `${baseUrl}/?embed=true`;
      iframe.style.width = '100%';
      iframe.style.border = 'none';
      iframe.style.overflow = 'hidden';
      iframe.scrolling = 'no';
      
      window.addEventListener('message', (event) => {
        if (event.origin !== baseUrl) return;
        if (event.data.type === 'resize') {
          iframe.style.height = event.data.height + 'px';
        }
      });

      container.appendChild(iframe);
      container.dataset.initialized = 'true';
    });
  }

  if (document.readyState === 'complete') {
    initWidgets();
  } else {
    window.addEventListener('load', initWidgets);
  }
})();

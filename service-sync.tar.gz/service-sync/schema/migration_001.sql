-- Migration: Add tenant branding and user verification
ALTER TABLE tenants 
ADD COLUMN logo_url TEXT,
ADD COLUMN contact_email TEXT,
ADD COLUMN contact_phone TEXT,
ADD COLUMN address TEXT,
ADD COLUMN primary_color TEXT DEFAULT '#3b82f6',
ADD COLUMN is_active BOOLEAN DEFAULT false;

ALTER TABLE users
ADD COLUMN email_verified BOOLEAN DEFAULT false,
ADD COLUMN email_verify_token TEXT;

-- Index for subdomain lookups (slug)
CREATE INDEX idx_tenants_slug ON tenants(slug);

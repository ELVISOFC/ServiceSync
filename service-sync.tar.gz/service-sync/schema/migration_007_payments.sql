-- Migration: Payment Integration (BTCPay Server)
ALTER TABLE services ADD COLUMN require_payment BOOLEAN NOT NULL DEFAULT false;

ALTER TABLE appointments 
ADD COLUMN invoice_id TEXT,
ADD COLUMN payment_status VARCHAR(20) DEFAULT 'none';

CREATE INDEX idx_appointments_invoice_id ON appointments(invoice_id);

-- Migration: Comprehensive RLS and isolation
DO $$ 
DECLARE
    t TEXT;
    table_list TEXT[] := ARRAY[
        'tenants', 'users', 'services', 'staff', 'staff_availability', 
        'leads', 'appointments', 'call_logs', 'sms_logs', 'lead_notes', 
        'workflows', 'workflow_execution_log', 'tenant_phone_numbers'
    ];
BEGIN
    FOREACH t IN ARRAY table_list LOOP
        EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
        EXECUTE format('DROP POLICY IF EXISTS %I_isolation_policy ON %I', t, t);
        
        IF t = 'tenants' THEN
            EXECUTE format('
                CREATE POLICY tenants_isolation_policy ON tenants
                USING (id = (NULLIF(current_setting(''app.current_tenant_id'', true), ''''))::uuid)
                WITH CHECK (id = (NULLIF(current_setting(''app.current_tenant_id'', true), ''''))::uuid)
            ');
        ELSE
            EXECUTE format('
                CREATE POLICY %I_isolation_policy ON %I
                USING (tenant_id = (NULLIF(current_setting(''app.current_tenant_id'', true), ''''))::uuid)
                WITH CHECK (tenant_id = (NULLIF(current_setting(''app.current_tenant_id'', true), ''''))::uuid)
            ', t, t);
        END IF;
    END LOOP;
END $$;

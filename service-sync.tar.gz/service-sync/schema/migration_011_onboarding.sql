-- Migration: Tenant Onboarding Wizard
CREATE TYPE onboarding_step_type AS ENUM ('profile', 'services', 'staff', 'hours', 'phone', 'complete');

ALTER TABLE tenants 
ADD COLUMN onboarding_step onboarding_step_type DEFAULT 'profile',
ADD COLUMN working_hours JSONB;

-- Update existing tenants to complete
UPDATE tenants SET onboarding_step = 'complete' WHERE onboarding_step IS NULL;

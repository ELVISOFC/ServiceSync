-- Migration: AI Voice Receptionist
CREATE TABLE tenant_phone_numbers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    phone_number TEXT UNIQUE NOT NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_tenant_phone_numbers_tenant ON tenant_phone_numbers(tenant_id);
CREATE INDEX idx_tenant_phone_numbers_number ON tenant_phone_numbers(phone_number);

-- Enable RLS
ALTER TABLE tenant_phone_numbers ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_phone_numbers_isolation ON tenant_phone_numbers
USING (tenant_id = (current_setting('app.current_tenant', true))::UUID)
WITH CHECK (tenant_id = (current_setting('app.current_tenant', true))::UUID);

-- Migration: Lead Management System
CREATE TABLE lead_notes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_lead_notes_lead_time ON lead_notes(lead_id, created_at);

-- Performance indexes for leads
CREATE INDEX idx_leads_tenant_status ON leads(tenant_id, status);
CREATE INDEX idx_leads_tenant_phone ON leads(tenant_id, phone);

-- Enable RLS for lead_notes
ALTER TABLE lead_notes ENABLE ROW LEVEL SECURITY;
CREATE POLICY lead_notes_tenant_isolation ON lead_notes
USING (tenant_id = (current_setting('app.current_tenant', true))::UUID)
WITH CHECK (tenant_id = (current_setting('app.current_tenant', true))::UUID);

-- Migration: Scheduling Engine Enhancements
ALTER TABLE services ADD COLUMN buffer_minutes INTEGER DEFAULT 0;
ALTER TABLE tenants ADD COLUMN timezone TEXT DEFAULT 'UTC';

-- Indexes for scheduling performance
CREATE INDEX idx_appointments_tenant_time ON appointments(tenant_id, start_time);
CREATE INDEX idx_staff_availability_staff_day ON staff_availability(staff_id, day_of_week);

-- Add sample data or common working hours if needed
-- For now, ensure existing data is consistent.

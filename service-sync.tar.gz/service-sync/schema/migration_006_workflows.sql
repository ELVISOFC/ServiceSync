-- Migration: Workflow Automation Engine
ALTER TABLE workflows 
ADD COLUMN description TEXT,
ADD COLUMN priority INTEGER DEFAULT 0,
ADD COLUMN updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP;

CREATE TABLE workflow_execution_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    workflow_id UUID NOT NULL REFERENCES workflows(id) ON DELETE CASCADE,
    event_type VARCHAR NOT NULL,
    event_data JSONB,
    success BOOLEAN DEFAULT true,
    output TEXT,
    executed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_workflow_exec_workflow ON workflow_execution_log(workflow_id, executed_at);
CREATE INDEX idx_workflows_trigger ON workflows(tenant_id, trigger_event) WHERE is_enabled = true;

-- Enable RLS
ALTER TABLE workflow_execution_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY workflow_exec_tenant_isolation ON workflow_execution_log
USING (tenant_id = (current_setting('app.current_tenant', true))::UUID)
WITH CHECK (tenant_id = (current_setting('app.current_tenant', true))::UUID);

-- Migration: Stripe Integration
ALTER TABLE services ADD COLUMN payment_provider TEXT CHECK (payment_provider IN ('stripe', 'btcpay')) DEFAULT 'btcpay';

#!/bin/bash
set -e

REPO_PATH="/home/agent-lead/servicesync.git"
TARGET_DIR="/opt/local-services"

echo "Creating bare repository at $REPO_PATH..."
mkdir -p "$REPO_PATH"
cd "$REPO_PATH"
git init --bare

echo "Creating post-receive hook..."
CAT << 'EOF' > hooks/post-receive
#!/bin/bash
TARGET="/opt/local-services"
GIT_DIR="/home/agent-lead/servicesync.git"

while read oldrev newrev refname
do
    if [ "$refname" = "refs/heads/main" ]; then
        echo "Main branch pushed. Deploying to $TARGET..."
        mkdir -p "$TARGET"
        git --work-tree="$TARGET" --git-dir="$GIT_DIR" checkout -f main
        cd "$TARGET"
        
        echo "Building and restarting production containers..."
        docker compose -f docker-compose.prod.yml up --build -d
    fi
done
EOF

chmod +x hooks/post-receive

echo "Setup complete."
echo "Remote URL: ssh://user@your-server-ip$REPO_PATH"
echo "Push to 'main' to trigger deployment."

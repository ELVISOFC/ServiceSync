#!/bin/bash
set -e

# Config
BACKUP_DIR="/home/agent-lead/backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=7

mkdir -p "$BACKUP_DIR"

echo "Starting PostgreSQL backup..."
docker exec servicesync-db-prod pg_dump -U $DB_USER servicesync > "$BACKUP_DIR/db_$TIMESTAMP.sql"

echo "Backing up volumes..."
tar -czf "$BACKUP_DIR/uploads_$TIMESTAMP.tar.gz" /home/agent-lead/service-sync/uploads
tar -czf "$BACKUP_DIR/recordings_$TIMESTAMP.tar.gz" /home/agent-lead/service-sync/freeswitch/recordings

echo "Cleaning up old backups..."
find "$BACKUP_DIR" -type f -mtime +$RETENTION_DAYS -delete

echo "Backup complete: $TIMESTAMP"
